          <!-- Main Footer -->
          <footer class="main-footer">
            <!-- To the right -->
            <div class="pull-right hidden-xs">
                <a href="http://laravel-boilerplate.com" target="_blank">{{ trans('strings.boilerplate_link') }}</a>
            </div>
            <!-- Default to the left -->
            <strong>Copyright &copy; 2015 <a href="#">Company</a>.</strong> {{ trans('strings.all_rights_reserved') }}
          </footer>