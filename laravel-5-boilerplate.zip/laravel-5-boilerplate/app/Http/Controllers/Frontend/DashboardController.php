<?php namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Fs;
use App\FsVersion;


/**
 * Class DashboardController
 * @package App\Http\Controllers\Frontend
 */
class DashboardController extends Controller {

	/**
	 * @return mixed
	 */
	public function index()
	{
			
		$user_fss =Fs::with('fs_versions')->where('user_id',auth()->user()->user_id)->get();
			// print_r($user_fss);die(); 
		return view('frontend.user.dashboard', ['user_fss' => $user_fss])
			->withUser(auth()->user());
	}
}