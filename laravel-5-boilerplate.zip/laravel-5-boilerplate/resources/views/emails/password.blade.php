{{ trans('strings.click_here_to_reset') . url('password/reset/' . $token) }}
