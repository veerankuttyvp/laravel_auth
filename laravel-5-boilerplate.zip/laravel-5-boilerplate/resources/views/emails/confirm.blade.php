{{ trans('strings.click_here_to_confirm_account') . url('account/confirm/' . $token) }}
