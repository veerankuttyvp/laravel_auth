<?php

get('dashboard', 'DashboardController@index')->name('backend.dashboard');